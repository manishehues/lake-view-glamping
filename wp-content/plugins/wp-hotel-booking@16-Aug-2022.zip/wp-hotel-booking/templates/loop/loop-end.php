<?php
/**
 * The template for displaying end loop room.
 *
 * This template can be overridden by copying it to yourtheme/wp-hotel-booking/loop/loop-end.php.
 *
 * @author  ThimPress, leehld
 * @package WP-Hotel-Booking/Templates
 * @version 1.6
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit();
?>

</ul>

<?php wp_reset_postdata(); ?>