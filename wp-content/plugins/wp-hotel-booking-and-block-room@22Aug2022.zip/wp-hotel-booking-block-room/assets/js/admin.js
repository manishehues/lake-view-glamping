(function ($) {
    $(document).ready(function () {
        // $('.select-block-rooms').select2();
    });
})(jQuery);
